/*
* Students: Baljit Sanghera and Farzan Syed
* Professor: Brian Pham
* Assignment: Assignment 3, Image Matching Game
* Class: PROG24178 Object Oriented Programming 2 - Java
* This program is an image matching game. When you click on two different
* pictures
* */
package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application {
Stage window;
    @Override
    public void start(Stage primaryStage) throws Exception{
//        Create the window and specify it's size in pixels.
//        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
//        primaryStage.setTitle("Baljit and Farzan's Matching Game");
//        primaryStage.setScene(new Scene(root, 500, 275));

//        Create the GridPane, it will arrange all of the images and any
//        buttons that are not a part of the game, start, stop for example.
        GridPane gridPane = new GridPane();
        gridPane.setMinSize(450,450);
        gridPane.setPadding(new Insets(10,10,10,10));
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setAlignment(Pos.CENTER);

//        Adding the labels to the girdPane.
        Label label1 = new Label("Label Test");
        gridPane.add(label1,0,1);

        Label label2 = new Label("Label Test 2");
        gridPane.add(label2,1,1);

        Image image = new Image("File:pictures/pic1.jpeg");
        ImageView imageView = new ImageView(image);
        imageView.setPreserveRatio(true);
        imageView.setFitHeight(100);
        gridPane.getChildren().add(imageView);

        Scene scene = new Scene(gridPane);
        primaryStage.setTitle("Baljit and Farzan's Matching Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
